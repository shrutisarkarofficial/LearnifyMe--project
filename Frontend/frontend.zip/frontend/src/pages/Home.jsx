import React from 'react';
import Header from '../componentes/layout/Header';
import Footer from '../componentes/layout/Footer';
const Home = () => {
  return (
    <>
      <Header /> {/* Header stays at the top */}
      <main style={{ marginTop: "80px", padding: "20px" }}> {/* Add some spacing */}
        <h1>Layout
          hiii
          byy byyy 
          Keep track of your shared expenses and balances with housemates, trips, groups, friends, and family.
          derfegtryrrsdnwekjfhkehtuietvb3u.
          45ry4iuty54y8t58yt54iueriuty8brt8rg6vtc7575765x.
          76z3xecrtvbynuvcxe5555cvbnbvcxc5vtbuy.
          rsxecrtbyuinivcx4z4x567esdfghjkl;
        </h1>
      </main>
      <Footer /> {/* Footer at the bottom */}
    </>
  );
};

export default Home;

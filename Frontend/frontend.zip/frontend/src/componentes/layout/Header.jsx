import React, { useState } from "react";
import { useNavigate } from "react-router-dom"; // Import useNavigate
import "../../style/Header.css";
import { FaBars, FaTimes } from "react-icons/fa";
import logoImage from "../../assets/react.svg";

const Header = () => {
  const [menuOpen, setMenuOpen] = useState(false);
  const navigate = useNavigate(); // Hook for navigation

  return (
    <nav className="navbar">
      <div className="navbar-container">
        {/* Logo */}
        <div className="logo">
          <img src={logoImage} alt="Logo" className="logo-icon" />
          MyWebsite
        </div>

        {/* Desktop Navigation */}
        <div className={`nav-links ${menuOpen ? "active" : ""}`}>
          <button className="btn sign-in">Log In</button>
          <button className="btn sign-up" onClick={() => navigate("/Signup")}>
            Sign Up
          </button>
        </div>

        {/* Mobile Menu Icon */}
        <div className="menu-icon" onClick={() => setMenuOpen(!menuOpen)}>
          {menuOpen ? <FaTimes /> : <FaBars />}
        </div>
      </div>
    </nav>
  );
};

export default Header;
